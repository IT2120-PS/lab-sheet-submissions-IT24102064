setwd("C:\\Users\\ASUS\\Desktop\\IT24102064")
getwd()
delivery_times <- read.table("Exercise - Lab 05.txt",header=TRUE)
head(delivery_times)


#2
times <- as.numeric(delivery_times$'Delivery_Time_(minutes)'
)
breaks <- seq(20, 70, by = 5) 

hist(times, 
     breaks = breaks, 
     right = FALSE,     
     col = "skyblue", 
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time (minutes)",
     ylab = "Frequency",
     border = "black")


#4

hist_data <- hist(times, breaks = breaks, right = FALSE, plot = FALSE)
cum_freq <- cumsum(hist_data$counts)
midpoints <- hist_data$breaks[-1]

plot(midpoints, cum_freq, 
     type = "o", col = "red", 
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency")




